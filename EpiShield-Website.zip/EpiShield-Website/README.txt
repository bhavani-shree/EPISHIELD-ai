EpiShield - production build (static website)

HOW TO GET A WORKING LINK (free, 1 minute):
1. Go to https://app.netlify.com/drop  (or Vercel / Cloudflare Pages)
2. Unzip this file, then drag the "EpiShield-Website" FOLDER onto the page.
3. You get a public link. Open it - all pages work (refresh also works).

Notes:
- No backend / database needed. Demo data is fictional and stored in the browser.
- Needs internet only for Google Fonts and OpenStreetMap map tiles.
- Host at the ROOT of a domain (not inside a sub-folder path).
